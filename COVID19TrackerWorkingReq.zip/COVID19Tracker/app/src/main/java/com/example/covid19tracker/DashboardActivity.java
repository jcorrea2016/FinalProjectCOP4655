package com.example.covid19tracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class DashboardActivity extends AppCompatActivity {
    private final int REQ_CODE = 100;
    private Button USAbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        Menu();

        USAbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoToUSAStats();
            }
        });
    }
    private void Menu() {
        USAbutton = findViewById(R.id.USAStats);
    }
    private void GoToUSAStats(){
        Intent intent = new Intent(DashboardActivity.this, StatisticsUSA.class);
        startActivity(intent);
    }
}


