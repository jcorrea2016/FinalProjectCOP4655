package com.example.covid19tracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TopCountryCases extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_country_cases);

        RequestQueue queue = Volley.newRequestQueue(this);

        String req = "https://corona.lmao.ninja/v2/countries?sort=cases";

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET,req,null,new Response.Listener<JSONArray>(){
            @Override
            public void onResponse(JSONArray response) {
                System.out.println(response);
                DisplayResults(response);
            }

        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error);
            }
        }
        );

        queue.add(jsonArrayRequest);
    }
    protected void DisplayResults( JSONArray response ) {
        String Results = "Top 5 Cases By Country: \n\n";
        String NL = "\n";


        final TextView textView = findViewById(R.id.DispTen);

        try {

            for(int i = 0; i < 5; i++){
                JSONObject tmp = response.getJSONObject(i);
                String countryname = tmp.getString("country");
                String cases = tmp.getString("cases");
                String deaths = tmp.getString("deaths");

                int rank = i+1;
                Results = Results + rank + ". " + "Country: " + countryname + NL + "Total Cases: " + cases + NL + "Total Deaths: " + deaths + NL + NL;
            }
            System.out.println(Results);

            textView.setText(Results);
        }
        catch(JSONException e){
            System.out.println("Error in string parsing");
            e.printStackTrace();
        }
    }
}
