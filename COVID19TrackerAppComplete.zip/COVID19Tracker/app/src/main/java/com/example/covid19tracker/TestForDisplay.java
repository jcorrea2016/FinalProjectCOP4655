package com.example.covid19tracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class TestForDisplay extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_for_display);

        Intent intent = getIntent();
        String name_input = intent.getStringExtra(StatesStatistics.EXTRA_MESSAGE);

        RequestQueue queue = Volley.newRequestQueue(this);

        String req = "https://corona.lmao.ninja/v2/states/" + name_input;

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,req,null,new Response.Listener<JSONObject>(){
            @Override
            public void onResponse(JSONObject response) {
                System.out.println(response);
                DisplayResults(response);
            }

        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error);
            }
        }
        );

        queue.add(jsonObjectRequest);
    }
    //gets the needed values  from the response and puts them into a string to be added to the TextView element
    protected void DisplayResults( JSONObject response ) {
        String Results;
        String NL = "\n";

        final TextView textView = findViewById(R.id.StateRet);

        try {
            String countryname = response.getString("state");
            String cases = response.getString("cases");
            String casesToday = response.getString("todayCases");
            String deaths = response.getString("deaths");
            String deathsToday = response.getString("todayDeaths");
            String activeCases = response.getString("active");

            Results = "State: " + countryname + NL + "Total Cases: " + cases + NL + "New Cases For Today: " + casesToday + NL + "Total Deaths: " + deaths + NL + "Deaths Today: " +
                    deathsToday + NL + "Active Cases: " + activeCases;

            System.out.println(Results);
            textView.setText(Results);
        }
        catch(JSONException e){
            System.out.println("Error in string parsing");
            e.printStackTrace();
        }
    }
}
