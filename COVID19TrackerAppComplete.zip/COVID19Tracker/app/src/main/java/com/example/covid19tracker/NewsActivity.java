package com.example.covid19tracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class NewsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        RequestQueue queue = Volley.newRequestQueue(this);

        String apikey = this.getString(R.string.newsapikey);

        String req = "https://newsapi.org/v2/everything?q=COVID19&from=2020-04-20&" +
                "language=en&sortBy=popularity&apiKey=" + apikey + "&pageSize=10&page=1";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,req,null,new Response.Listener<JSONObject>(){
            @Override
            public void onResponse(JSONObject response) {
                System.out.println(response);
                DisplayResults(response);
            }

        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error);
            }
        }
        );

        queue.add(jsonObjectRequest);
    }
    //gets the needed values  from the response and puts them into a string to be added to the TextView element
    protected void DisplayResults( JSONObject response ) {
        String Results = "Weekly Coronavirus Headlines:\n\n";
        String NL = "\n";

        final TextView textView = findViewById(R.id.DispHeadlines);

        try {
            JSONArray newsret = response.getJSONArray("articles");
            //loop used to get the top 10 news stories, then assigns the value to the Results string
            //indexing is done at the first line of the loop, with a tmp object holding the response

            for (int i = 0; i<newsret.length(); i++){
                JSONObject tmp = newsret.getJSONObject(i);
                String url = tmp.getString("url");
                String title = tmp.getString("title");
                JSONObject source = tmp.getJSONObject("source");
                String sname = source.getString("name");

                Results = Results + "Source: " + sname + NL + "Article: " + title + NL + "URL: " + url + NL + NL;
            }

            Results = Results + NL + NL + "Thank you to newsapi.org for supplying these headlines!";
            //System.out.println(Results);
            textView.setText(Results);
        }
        catch(JSONException e){
            System.out.println("Error in string parsing");
            e.printStackTrace();
        }
    }
}
