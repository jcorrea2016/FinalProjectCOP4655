package com.example.covid19tracker;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class StatesStatistics extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.covid19tracker.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_states_statistics);

    }
    public void sendReq(View view){
        Intent intent2 = new Intent(this, TestForDisplay.class);
        EditText editText = (EditText) findViewById(R.id.editText);
        String message1 = editText.getText().toString();
        intent2.putExtra(EXTRA_MESSAGE, message1);
        startActivity(intent2);
    }

}
