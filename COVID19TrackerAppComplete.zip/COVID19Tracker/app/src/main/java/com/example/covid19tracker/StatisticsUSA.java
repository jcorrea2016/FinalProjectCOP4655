package com.example.covid19tracker;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;


public class StatisticsUSA extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics_u_s);

        RequestQueue queue = Volley.newRequestQueue(this);

        String req = "https://corona.lmao.ninja/v2/countries/USA";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,req,null,new Response.Listener<JSONObject>(){
            @Override
            public void onResponse(JSONObject response) {
                System.out.println(response);
                DisplayResults(response);
            }

        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error);
            }
        }
        );

        queue.add(jsonObjectRequest);
    }
    //gets the needed values  from the response and puts them into a string to be added to the TextView element
    protected void DisplayResults( JSONObject response ) {
        String Results;
        String NL = "\n";

        final TextView textView = findViewById(R.id.textView);

        try {
            JSONObject countryinfo = response.getJSONObject("countryInfo");
            String countryname = response.getString("country");
            String cases = response.getString("cases");
            String casesToday = response.getString("todayCases");
            String deaths = response.getString("deaths");
            String deathsToday = response.getString("todayDeaths");
            String recoveries = response.getString("recovered");
            String activeCases = response.getString("active");
            String criticalCases = response.getString("critical");

            Results = "Country: " + countryname + NL + "Total Cases: " + cases + NL + "New Cases For Today: " + casesToday + NL + "Total Deaths: " + deaths + NL + "Deaths Today: " +
                    deathsToday + NL + "Total Recovered: " + recoveries + NL + "Active Cases: " + activeCases + NL + "Active Cases in Critical Condition: " + criticalCases;

            System.out.println(Results);
            textView.setText(Results);
        }
        catch(JSONException e){
            System.out.println("Error in string parsing");
            e.printStackTrace();
        }
    }
}
